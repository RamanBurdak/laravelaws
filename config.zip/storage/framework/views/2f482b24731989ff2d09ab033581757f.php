<?php $__env->startSection('content'); ?>
    <!-- Page Heading -->
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800">Dashboard</h1>
    </div>

    <!-- Statistics Row -->
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('backend.dashboard-statistics-component', [])->html();
} elseif ($_instance->childHasBeenRendered('XIkaO98')) {
    $componentId = $_instance->getRenderedChildComponentId('XIkaO98');
    $componentTag = $_instance->getRenderedChildComponentTagName('XIkaO98');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('XIkaO98');
} else {
    $response = \Livewire\Livewire::mount('backend.dashboard-statistics-component', []);
    $html = $response->html();
    $_instance->logRenderedChild('XIkaO98', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

    <!-- Chart Row -->
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('backend.dashboard-chart-component', [])->html();
} elseif ($_instance->childHasBeenRendered('vWszHpV')) {
    $componentId = $_instance->getRenderedChildComponentId('vWszHpV');
    $componentTag = $_instance->getRenderedChildComponentTagName('vWszHpV');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('vWszHpV');
} else {
    $response = \Livewire\Livewire::mount('backend.dashboard-chart-component', []);
    $html = $response->html();
    $_instance->logRenderedChild('vWszHpV', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\xampp\htdocs\laravel-ecommerce-main\resources\views/backend/index.blade.php ENDPATH**/ ?>