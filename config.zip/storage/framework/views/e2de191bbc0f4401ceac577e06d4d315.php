<ul>
    <li><a href="<?php echo e(route('wishlist.index')); ?>"><i class="ti-heart"></i>(<?php echo e($wishlistCount); ?>) Wishlist</a></li>
</ul>
<?php /**PATH G:\xampp\htdocs\laravel-ecommerce-main\resources\views/livewire/frontend/header/wishlist-component.blade.php ENDPATH**/ ?>