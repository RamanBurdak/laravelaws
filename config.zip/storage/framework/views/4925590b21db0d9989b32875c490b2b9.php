<footer class="sticky-footer bg-white">
    <div class="container my-auto">
        <div class="copyright text-center my-auto">
            <span>Copyright &copy; alialqahtani.sa</span>
            <script>
                document.write(new Date().getFullYear())
            </script>
        </div>
    </div>
</footer>
<?php /**PATH G:\xampp\htdocs\laravel-ecommerce-main\resources\views/partials/backend/footer.blade.php ENDPATH**/ ?>