<?php $__env->startSection('title', 'Shop products'); ?>
<?php $__env->startSection('content'); ?>
    <div class="shop-page-wrapper shop-page-padding ptb-100">
        <div class="container m-auto">
            <div class="row">
                <div class="col-lg-3">
                    <?php echo $__env->make('partials.frontend.shop.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
                <div class="col-lg-9">
                    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('frontend.product.shop-products-component', ['slug' => $slug])->html();
} elseif ($_instance->childHasBeenRendered('BWEKlK1')) {
    $componentId = $_instance->getRenderedChildComponentId('BWEKlK1');
    $componentTag = $_instance->getRenderedChildComponentTagName('BWEKlK1');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('BWEKlK1');
} else {
    $response = \Livewire\Livewire::mount('frontend.product.shop-products-component', ['slug' => $slug]);
    $html = $response->html();
    $_instance->logRenderedChild('BWEKlK1', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\xampp\htdocs\laravel-ecommerce-main\resources\views/frontend/shop/index.blade.php ENDPATH**/ ?>