<?php $__env->startSection('title', 'Homepage'); ?>
<?php $__env->startSection('content'); ?>
<!-- promotion area start -->
<?php if($coupon): ?>
<div class="p-1 text-white text-center"
     style="background-image: url('<?php echo e(asset('frontend/img/bg/12.jpg')); ?>')">
    <?php echo e($coupon->value); ?><?php echo e($coupon->type == 'percentage' ? '%' : ''); ?> off use (<?php echo e($coupon->code); ?>)
</div>
<?php endif; ?>
<!-- promotion area end -->

<?php echo $__env->make('partials.frontend.sliders', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- categories area start -->
<div class="container">
    <div class="pb-50">
        <div class="section-title-furits text-center">
            <img src="<?php echo e(asset('frontend/img/icon-img/49.png')); ?>" alt="">
            <h2>BROWSE OUR CATEGORIES</h2>
        </div>
        <br>
        <section>
            <header class="text-center">
                <p class="small text-muted small text-uppercase mb-1">Carefully created collections</p>
                <h2 class="h5 text-uppercase mb-4">Browse our categories</h2>
            </header>
            <div class="row">
                <div class="col-md-4 mb-4 mb-md-0">
                    <a class="category-item" href="<?php echo e(route('shop.index', $categories[0]->slug ?? '')); ?>">
                        <?php if($categories[0]->cover ?? ''): ?>
                            <img class="img-fluid"
                                 src="<?php echo e(asset('storage/images/categories/' . $categories[0]->cover ?? '')); ?>"
                                 alt="<?php echo e($categories[0]->name ?? ''); ?>">
                        <?php else: ?>
                            <img class="img-fluid" src="<?php echo e(asset('frontend/assets/categories/cat-img-1.jpg')); ?>" alt="">
                        <?php endif; ?>
                        <strong class="category-item-title"><?php echo e($categories[0]->name ?? ''); ?></strong>
                    </a>
                </div>
                <div class="col-md-4 mb-4 mb-md-0">
                    <a class="category-item mb-4" href="<?php echo e(route('shop.index', $categories[1]->slug ?? '')); ?>">
                        <?php if($categories[1]->cover ?? ''): ?>
                        <img class="img-fluid"
                             src="<?php echo e(asset('storage/images/categories/' . $categories[1]->cover ?? '')); ?>"
                             alt="<?php echo e($categories[1]->name ?? ''); ?>">
                        <?php else: ?>
                            <img class="img-fluid"
                                 style="margin: 7px;"
                                 src="<?php echo e(asset('frontend/assets/categories/cat-img-2.jpg')); ?>"
                                 alt="<?php echo e($categories[1]->name ?? ''); ?>">
                        <?php endif; ?>
                        <strong class="category-item-title" style="margin-top: -124px;"><?php echo e($categories[1]->name ?? ''); ?></strong>
                    </a>
                    <a class="category-item" href="<?php echo e(route('shop.index', $categories[2]->slug ?? '')); ?>">
                        <?php if($categories[2]->cover ?? ''): ?>
                        <img class="img-fluid"
                             src="<?php echo e(asset('storage/images/categories/' . $categories[2]->cover ?? '')); ?>"
                             alt="<?php echo e($categories[2]->name ?? ''); ?>">
                        <?php else: ?>
                            <img class="img-fluid"
                                 style="margin: 9px;"
                                 src="<?php echo e(asset('frontend/assets/categories/cat-img-3.jpg')); ?>"
                                 alt="<?php echo e($categories[2]->name ?? ''); ?>">
                        <?php endif; ?>
                        <strong class="category-item-title" style="margin-top: 104px;"><?php echo e($categories[2]->name ?? ''); ?></strong>
                    </a>
                </div>
                <div class="col-md-4">
                    <a class="category-item" href="<?php echo e(route('shop.index', $categories[3]->slug ?? '')); ?>">
                        <?php if($categories[3]->cover ?? ''): ?>
                        <img class="img-fluid"
                             src="<?php echo e(asset('storage/images/categories/' . $categories[3]->cover ?? '')); ?>"
                             alt="">
                        <?php else: ?>
                            <img class="img-fluid" src="<?php echo e(asset('frontend/assets/categories/cat-img-4.jpg')); ?>"
                                 alt="<?php echo e($categories[3]->name ?? ''); ?>">
                        <?php endif; ?>
                        <strong class="category-item-title"><?php echo e($categories[3]->name ?? ''); ?></strong>
                    </a>
                </div>
            </div>
        </section>
    </div>
</div>
<!-- categories area end -->

<!-- banner area start -->
<div class="fruits-choose-area pb-65 bg-img mt-5" style="background-image: url('<?php echo e(asset('frontend/img/banner/53.png')); ?>')">
    <div class="container">
        <div class="row">
            <div class="col-lg-12 col-xl-8 col-12">
                <div class="fruits-choose-wrapper-all">
                    <div class="fruits-choose-title mt-5">
                        <h2>WHY CHOOSE US ?</h2>
                    </div>
                    <div class="fruits-choose-wrapper">
                        <div class="single-fruits-choose">
                            <div class="fruits-choose-serial">
                                <h3>01</h3>
                            </div>
                            <div class="fruits-choose-content">
                                <h4>Free Shipping.</h4>
                                <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
                            </div>
                        </div>
                        <div class="single-fruits-choose">
                            <div class="fruits-choose-serial">
                                <h3>02</h3>
                            </div>
                            <div class="fruits-choose-content">
                                <h4>100% ORIGINAL PRODUCTS.</h4>
                                <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
                            </div>
                        </div>
                        <div class="single-fruits-choose">
                            <div class="fruits-choose-serial">
                                <h3>03</h3>
                            </div>
                            <div class="fruits-choose-content">
                                <h4>Online Support.</h4>
                                <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- banner area end -->

<!-- TRENDING PRODUCTS -->
<div class="container">
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('frontend.product.top-trending-products', [])->html();
} elseif ($_instance->childHasBeenRendered('XgJkQXk')) {
    $componentId = $_instance->getRenderedChildComponentId('XgJkQXk');
    $componentTag = $_instance->getRenderedChildComponentTagName('XgJkQXk');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('XgJkQXk');
} else {
    $response = \Livewire\Livewire::mount('frontend.product.top-trending-products', []);
    $html = $response->html();
    $_instance->logRenderedChild('XgJkQXk', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
</div>

<!-- services area start -->
<div class="fruits-services ptb-200">
    <div class="fruits-services-wrapper">
        <div class="single-fruits-services">
            <div class="fruits-services-img">
                <img src="<?php echo e(asset('img/logo.png')); ?>" alt="">
            </div>
            <div class="fruits-services-content">
                <h4>Free Shipping</h4>
                <p>Lorem Ipsum is simply dummy text of the and typesetting industry. Lorem Ipsum is simply
                    industry.</p>
            </div>
        </div>
        <div class="single-fruits-services">
            <div class="fruits-services-img">
                <img src="<?php echo e(asset('img/logo.png')); ?>" alt="">
            </div>
            <div class="fruits-services-content">
                <h4>Money Guarentee.</h4>
                <p>Lorem Ipsum is simply dummy text of the and typesetting industry. Lorem Ipsum is simply
                    industry.</p>
            </div>
        </div>
        <div class="single-fruits-services">
            <div class="fruits-services-img">
                <img src="<?php echo e(asset('img/logo.png')); ?>" alt="">
            </div>
            <div class="fruits-services-content">
                <h4>Online Support</h4>
                <p>Lorem Ipsum is simply dummy text of the and typesetting industry. Lorem Ipsum is simply
                    industry.</p>
            </div>
        </div>
    </div>
</div>
<!-- services area end -->
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\xampp\htdocs\laravel-ecommerce-main\resources\views/frontend/index.blade.php ENDPATH**/ ?>