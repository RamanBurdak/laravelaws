<div class="header-cart-4 furits-cart">

    <a class="icon-cart" href="<?php echo e(route('cart.index')); ?>">
        <i class="ti-shopping-cart"></i>
        <span><?php echo e($cartCount); ?></span>
    </a>








</div>
<?php /**PATH G:\xampp\htdocs\laravel-ecommerce-main\resources\views/livewire/frontend/header/cart-component.blade.php ENDPATH**/ ?>