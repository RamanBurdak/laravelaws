<nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">

    <!-- Sidebar Toggle (Topbar) -->
    <button id="sidebarToggleTop" class="btn btn-link d-md-none rounded-circle mr-3">
        <i class="fa fa-bars"></i>
    </button>

    <!-- Topbar Navbar -->
    <ul class="navbar-nav ml-auto">

        <!-- Nav Item - Alerts -->
        <li class="nav-item dropdown no-arrow mx-1">
            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('backend.notification-component', [])->html();
} elseif ($_instance->childHasBeenRendered('49wwC8k')) {
    $componentId = $_instance->getRenderedChildComponentId('49wwC8k');
    $componentTag = $_instance->getRenderedChildComponentTagName('49wwC8k');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('49wwC8k');
} else {
    $response = \Livewire\Livewire::mount('backend.notification-component', []);
    $html = $response->html();
    $_instance->logRenderedChild('49wwC8k', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
        </li>

        <!-- Nav Item - Messages -->
        

        <!-- Supervisor link -->
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('access_link')): ?>
            <li class="nav-item">
                <a class="nav-link text-dark" href="<?php echo e(route('admin.links.index')); ?>">Links</a>
            </li>
        <?php endif; ?>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('access_supervisor')): ?>
            <li class="nav-item">
                <a class="nav-link text-dark" href="<?php echo e(route('admin.supervisors.index')); ?>">Supervisors</a>
            </li>
        <?php endif; ?>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('access_setting')): ?>
            <li class="nav-item">
                <a class="nav-link" href="<?php echo e(route('admin.settings.index')); ?>">
                    <span>Settings</span></a>
            </li>
        <?php endif; ?>

        <div class="topbar-divider d-none d-sm-block"></div>

        <!-- Nav Item - User Information -->
        <li class="nav-item dropdown no-arrow">
            <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button"
               data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                <?php if(auth()->guard()->check()): ?>
                    <span class="mr-2 d-none d-lg-inline text-gray-600 small"><?php echo e(auth()->user()->first_name); ?></span>
                <?php endif; ?>
                <?php if(auth()->user()->user_image): ?>
                    <img class="img-profile rounded-circle" src="<?php echo e(asset('storage/images/users/' . auth()->user()->user_image)); ?>"
                         alt="<?php echo e(auth()->user()->full_name); ?>">
                <?php else: ?>
                    <img class="img-profile rounded-circle" src="<?php echo e(asset('img/avatar.png')); ?>" alt="">
                <?php endif; ?>
            </a>
            <!-- Dropdown - User Information -->
            <div class="dropdown-menu dropdown-menu-right shadow animated--grow-in"
                 aria-labelledby="userDropdown">
                <a class="dropdown-item" href="<?php echo e(route('admin.account_setting')); ?>">
                    <i class="fas fa-user fa-sm fa-fw mr-2 text-gray-400"></i>
                    Profile
                </a>

                <div class="dropdown-divider"></div>

                <?php if(auth()->guard()->check()): ?>
                <a class="dropdown-item" href="#" data-toggle="modal" data-target="#logoutModal">
                    <i class="fas fa-sign-out-alt fa-sm fa-fw mr-2 text-gray-400"></i>
                    Logout
                </a>
                <?php endif; ?>
            </div>
        </li>

    </ul>

</nav>
<?php /**PATH G:\xampp\htdocs\laravel-ecommerce-main\resources\views/partials/backend/navbar.blade.php ENDPATH**/ ?>