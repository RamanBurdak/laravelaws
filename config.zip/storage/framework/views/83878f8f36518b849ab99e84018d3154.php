<?php echo e($slot); ?>

<?php /**PATH G:\xampp\htdocs\laravel-ecommerce-main\resources\views/vendor/mail/text/footer.blade.php ENDPATH**/ ?>