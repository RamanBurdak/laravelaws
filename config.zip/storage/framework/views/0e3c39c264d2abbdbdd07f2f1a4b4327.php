<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="author" content="Ali">
    <meta name="description" content="E-commerce Application">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <link rel="shortcut icon" href="<?php echo e(asset('favicon.ico')); ?>">
    <title><?php echo e(config('app.name', 'Laravel')); ?> | <?php echo $__env->yieldContent('title', 'Dashboard'); ?></title>
    <!-- Fonts -->
    <link href="<?php echo e(asset('backend/vendor/fontawesome-free/css/all.min.css')); ?>" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">
    <!-- Styles -->
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('backend/css/sb-admin-2.min.css')); ?>" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo e(asset('backend/vendor/bootstrap-fileinput/css/fileinput.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('backend/vendor/summernote/summernote-bs4.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('backend/css/custom.css')); ?>">
    <?php echo \Livewire\Livewire::styles(); ?>

    <?php echo $__env->yieldContent('styles'); ?>
</head>
<body id="page-top">

    <div id="app">
        <div id="wrapper">
            <?php echo $__env->make('partials.backend.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div id="content-wrapper" class="d-flex flex-column">
                <div id="content">
                    <?php echo $__env->make('partials.backend.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <!-- Begin Page Content -->
                    <div class="container-fluid">
                        <?php echo $__env->make('partials.backend.flash', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <?php echo $__env->yieldContent('content'); ?>
                    </div>
                </div>
                <?php echo $__env->make('partials.backend.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
        </div>
        <!-- Scroll to Top Button-->
        <a class="scroll-to-top rounded" href="#page-top">
            <i class="fas fa-angle-up"></i>
        </a>

        <?php echo $__env->make('partials.backend.modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
    <?php echo \Livewire\Livewire::scripts(); ?>

    <script src="<?php echo e(asset('js/app.js')); ?>"></script>
    <script src="<?php echo e(asset('backend/vendor/jquery-easing/jquery.easing.min.js')); ?>"></script>
    <script src="<?php echo e(asset('backend/js/sb-admin-2.min.js')); ?>"></script>
    <script src="<?php echo e(asset('backend/js/custom.js')); ?>"></script>
    <!-- file input -->
    <script src="<?php echo e(asset('backend/vendor/bootstrap-fileinput/js/plugins/piexif.min.js')); ?>"></script>
    <script src="<?php echo e(asset('backend/vendor/bootstrap-fileinput/js/plugins/sortable.min.js')); ?>"></script>
    <script src="<?php echo e(asset('backend/vendor/bootstrap-fileinput/js/fileinput.min.js')); ?>"></script>
    <script src="<?php echo e(asset('backend/vendor/bootstrap-fileinput/themes/fas/theme.min.js')); ?>"></script>
    <!-- summernote -->
    <script src="<?php echo e(asset('backend/vendor/summernote/summernote-bs4.min.js')); ?>"></script>
    <?php echo $__env->yieldContent('scripts'); ?>
</body>
</html>
<?php /**PATH G:\xampp\htdocs\laravel-ecommerce-main\resources\views/layouts/admin.blade.php ENDPATH**/ ?>