<div>
    <a class="notification" href="#" id="alertsDropdown" role="button"
       data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
        <i class="fas fa-user-alt text-dark"></i>
        <span class="badge"><?php echo e($unReadNotificationsCount); ?></span>
    </a>
    <div class=" dropdown-menu dropdown-menu-right shadow animated--grow-in" aria-labelledby="alertsDropdown">
        <h6 class="dropdown-header"></h6>
        <?php $__empty_1 = true; $__currentLoopData = $unReadNotifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <?php if($notification->type == 'App\Notifications\Frontend\User\OrderThanksNotification'): ?>
                <a class="dropdown-item d-flex align-items-center" wire:click="markAsRead('<?php echo e($notification->id); ?>')">
                    <div>
                        <div class="small text-gray-500">
                            <?php echo e($notification->data['created_date']); ?>

                        </div>
                        <span class="font-weight-bold">
                            Order #<?php echo e($notification->data['order_ref']); ?> completed successfully.
                        </span>
                    </div>
                </a>
            <?php endif; ?>
            <?php if($notification->type == 'App\Notifications\Frontend\User\OrderStatusNotification'): ?>
                <a class="dropdown-item d-flex align-items-center" wire:click="markAsRead('<?php echo e($notification->id); ?>')">
                    <div>
                        <div class="small text-gray-500">
                            <?php echo e($notification->data['created_date']); ?>

                        </div>
                        <span class="font-weight-bold text-secondary">Order #<?php echo e($notification->data['order_ref']); ?></span>
                        <span class="badge badge-danger"><?php echo e($notification->data['last_transaction']); ?></span>
                    </div>
                </a>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <div class="dropdown-item text-center">No notifications found!</div>
        <?php endif; ?>
    </div>
</div>
<?php /**PATH G:\xampp\htdocs\laravel-ecommerce-main\resources\views/livewire/frontend/header/notification-component.blade.php ENDPATH**/ ?>