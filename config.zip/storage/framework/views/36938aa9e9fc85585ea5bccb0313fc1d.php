<?php $__empty_1 = true; $__currentLoopData = $pages_menu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
    <li>
        <a href="<?php echo e(route('page.show', $page->slug)); ?>"><?php echo e($page->title); ?></a>
    </li>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
<?php endif; ?>
<?php /**PATH G:\xampp\htdocs\laravel-ecommerce-main\resources\views/partials/frontend/pages.blade.php ENDPATH**/ ?>