<?php echo e($slot); ?>

<?php /**PATH G:\xampp\htdocs\laravel-ecommerce-main\resources\views/vendor/mail/text/subcopy.blade.php ENDPATH**/ ?>