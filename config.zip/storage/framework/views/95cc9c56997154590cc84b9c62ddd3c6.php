<header class="ptb-50">
    <div class="header-bottom wrapper-padding-2 res-header-sm sticker header-sticky-3 furits-header">
        <div class="container-fluid">
            <div class="header-bottom-wrapper ">
                <div class="logo-2 ptb-35 menu-hover">
                    <a href="<?php echo e(route('home')); ?>">
                        <img style="width: 150px" src="<?php echo e(asset('img/logo.png')); ?>" alt="">
                    </a>
                </div>
                <div class="menu-style-2 handicraft-menu menu-hover">
                    <nav>
                        <ul>
                            <li><a href="<?php echo e(route('home')); ?>">Home</a></li>
                            <li>
                                <a href="<?php echo e(route('shop.index')); ?>">
                                    Products
                                </a>
                            </li>
                            <ul class="single-dropdown">
                                <li>
                                    <a href="<?php echo e(route('contact.index')); ?>">Contact us</a>
                                </li>
                                <?php if(auth()->guard()->guest()): ?>
                                    <li>
                                        <a href="<?php echo e(route('login')); ?>">Login</a>
                                    </li>
                                    <?php if(route('register')): ?>
                                        <li>
                                            <a href="<?php echo e(route('register')); ?>">Register</a>
                                        </li>
                                    <?php endif; ?>
                                <?php endif; ?>
                                <li>
                                    <a href="<?php echo e(route('cart.index')); ?>">Cart page</a>
                                </li>
                            </ul>
                            <li>
                                <a href="javascript:void(0);">Categories</a>
                                <ul class="single-dropdown">
                                    <?php $__currentLoopData = $shop_categories_menu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $global_category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li>
                                            <a href="<?php echo e(route('shop.index', $global_category->slug)); ?>">
                                                <?php echo e($global_category->name); ?>

                                            </a>
                                        </li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </li>
                            <li>
                                <a href="javascript:void(0);">Pages</a>
                                <ul class="single-dropdown">
                                    <?php echo $__env->make('partials.frontend.pages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                </ul>
                            </li>
                            <li>
                                <a href="<?php echo e(route('contact.index')); ?>">Contact</a>
                            </li>
                        </ul>
                    </nav>
                </div>
                <div class="furits-login-cart">
                    <div class="furits-login menu-hover">
                        <ul>
                            <?php if(auth()->guard()->guest()): ?>
                                <li><a href="<?php echo e(route('login')); ?>">Login</a></li>
                                <li><a href="<?php echo e(route('register')); ?>">Reg</a></li>
                            <?php else: ?>
                                <li>
                                    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('frontend.header.notification-component', [])->html();
} elseif ($_instance->childHasBeenRendered('a7Z32YL')) {
    $componentId = $_instance->getRenderedChildComponentId('a7Z32YL');
    $componentTag = $_instance->getRenderedChildComponentTagName('a7Z32YL');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('a7Z32YL');
} else {
    $response = \Livewire\Livewire::mount('frontend.header.notification-component', []);
    $html = $response->html();
    $_instance->logRenderedChild('a7Z32YL', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                                </li>

                                <li>
                                    <a href="javascript:void(0);" style="color: #578a01;">My Account</a>
                                    <ul class="single-dropdown">
                                        <?php if(\Spatie\Permission\PermissionServiceProvider::bladeMethodWrapper('hasRole', 'admin')): ?>
                                        <li>
                                            <a href="<?php echo e(route('admin.index')); ?>" style="color: #578a01;">
                                                Administration
                                            </a>
                                        <?php endif; ?>
                                        <?php if(auth()->guard()->check()): ?>
                                            <li><a href="<?php echo e(route('user.dashboard')); ?>" style="color: #578a01;">Dashboard</a>
                                            </li>
                                        <?php endif; ?>
                                        <li>
                                            <a class="dropdown-item" href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault(); document.getElementById('logout-form').submit();" style="color: #578a01;">
                                                <?php echo e(__('Logout')); ?>

                                            </a>
                                            <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST"
                                                  style="display: none;">
                                                <?php echo csrf_field(); ?>
                                            </form>
                                        </li>
                                    </ul>
                                </li>
                            <?php endif; ?>
                        </ul>
                    </div>
                    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('frontend.header.cart-component', [])->html();
} elseif ($_instance->childHasBeenRendered('A84XMiI')) {
    $componentId = $_instance->getRenderedChildComponentId('A84XMiI');
    $componentTag = $_instance->getRenderedChildComponentTagName('A84XMiI');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('A84XMiI');
} else {
    $response = \Livewire\Livewire::mount('frontend.header.cart-component', []);
    $html = $response->html();
    $_instance->logRenderedChild('A84XMiI', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                </div>
            </div>
            <div class="row">
                <div class="mobile-menu-area d-md-block col-md-12 col-lg-12 col-12 d-lg-none d-xl-none">
                    <div class="mobile-menu">
                        <nav id="mobile-menu-active">
                            <ul class="menu-overflow">
                                <li><a href="<?php echo e(route('home')); ?>">HOME</a></li>
                                <li><a href="<?php echo e(route('shop.index')); ?>">PRODUCTS</a></li>
                                <li><a href="#">Categories</a>
                                    <ul>
                                        <li>
                                        <?php $__currentLoopData = $shop_categories_menu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $global_category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li>
                                                <a href="<?php echo e(route('shop.index', $global_category->slug)); ?>">
                                                    <?php echo e($global_category->name); ?>

                                                </a>
                                            </li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                </li>
                                <li><a href="<?php echo e(route('contact.index')); ?>">contact</a></li>
                                <?php if(auth()->guard()->guest()): ?>
                                    <li>
                                        <a href="<?php echo e(route('login')); ?>">Login</a>
                                    </li>
                                    <li>
                                        <a href="<?php echo e(route('register')); ?>">Reg</a>
                                    </li>
                                <?php else: ?>
                                    <?php if(\Spatie\Permission\PermissionServiceProvider::bladeMethodWrapper('hasRole', 'admin')): ?>
                                        <li><a href="<?php echo e(route('admin.index')); ?>">Administration</a>
                                    <?php endif; ?>
                                    <?php if(\Spatie\Permission\PermissionServiceProvider::bladeMethodWrapper('hasRole', 'supervisor')): ?>
                                        <li><a href="<?php echo e(route('admin.index')); ?>">Administration</a>
                                    <?php endif; ?>
                                    <li><a href="<?php echo e(route('user.dashboard')); ?>">Dashboard</a></li>
                                    <li>
                                        <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                                           onclick="event.preventDefault();
                                    document.getElementById('logout-form').submit();">
                                            <?php echo e(__('Logout')); ?>

                                        </a>
                                        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST"
                                              style="display: none;">
                                            <?php echo csrf_field(); ?>
                                        </form>
                                    </li>
                                <?php endif; ?>
                                <?php echo $__env->make('partials.frontend.pages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            </ul>
                        </nav>
                    </div>
                </div>
            </div>
        </div>
    </div>
</header>
<div class="breadcrumb-area pt-50">

    <div class="container-fluid">
        <div class="furniture-bottom-wrapper">
            <div class="furniture-login">
            </div>
            <div class="furniture-search">
                <form>
                    <div class="form-input">
                        <input id="search" type="text"
                               value="<?php echo e(old('keyword', request()->keyword)); ?>"
                               placeholder="Search for product...">
                    </div>
                </form>
            </div>
            <div class="furniture-wishlist">
                <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('frontend.header.wishlist-component', [])->html();
} elseif ($_instance->childHasBeenRendered('GLbc8mf')) {
    $componentId = $_instance->getRenderedChildComponentId('GLbc8mf');
    $componentTag = $_instance->getRenderedChildComponentTagName('GLbc8mf');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('GLbc8mf');
} else {
    $response = \Livewire\Livewire::mount('frontend.header.wishlist-component', []);
    $html = $response->html();
    $_instance->logRenderedChild('GLbc8mf', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                <li><a href="#"></a></li>
                <li><a href="#"></a></li>
            </div>
        </div>
    </div>
</div>
<?php /**PATH G:\xampp\htdocs\laravel-ecommerce-main\resources\views/partials/frontend/header.blade.php ENDPATH**/ ?>