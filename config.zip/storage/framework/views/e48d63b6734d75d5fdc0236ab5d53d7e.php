<div class="slider-area">
    <div class="slider-active-2 owl-carousel">
        <div class="single-slider-4 bg-img furits-slider" style="background-image: url('<?php echo e(asset('frontend/img/slider/carousel.png')); ?>')">
            <div class="container">
                <div class="fadeinup-animated furits-content text-left">
                    <img class="animated" src="" alt="">
                    <p class="animated"></p>
                </div>
            </div>
        </div>
    </div>
    <br>
    <div class="slider-social">
        <span>
            <a class="furits-slider-btn btn-hover animated" href="<?php echo e(route('shop.index')); ?>">
                Shop Now
            </a>
        </span>
    </div>
</div>
<?php /**PATH G:\xampp\htdocs\laravel-ecommerce-main\resources\views/partials/frontend/sliders.blade.php ENDPATH**/ ?>