<div class="shop-sidebar mr-50">
    <div class="sidebar-widget mb-40">
        <h3 class="sidebar-title">CATEGORIES</h3>
        <?php $__empty_1 = true; $__currentLoopData = $shop_categories_menu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="py-2 px-4 bg-dark text-white mb-3">
                <strong class="small text-uppercase font-weight-bold">
                    <a class="text-decoration-none text-white" href="<?php echo e(route('shop.index', $category->slug)); ?>">
                        <?php echo e($category->name); ?>

                    </a>
                </strong>
            </div>
            <ul class="list-unstyled small text-muted pl-lg-4 font-weight-normal">
                <?php $__empty_2 = true; $__currentLoopData = $category->appearedChildren; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub_category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_2 = false; ?>
                    <li class="mb-2">
                        <a class="reset-anchor" href="<?php echo e(route('shop.index', $sub_category->slug)); ?>">
                            <?php echo e($sub_category->name); ?>

                        </a>
                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_2): ?>
                <?php endif; ?>
            </ul>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <?php endif; ?>
    </div>
    <div class="sidebar-widget mb-40">
        <h3 class="sidebar-title">TAGS</h3>
        <hr style="margin-top: 0; margin-bottom: 10px; border: solid 1px;">
        <div class="price_filter">

            <div class="price_slider_amount">
                <div class="sidebar-categories">
                    <ul>
                        <?php $__currentLoopData = $shop_tags_menu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <span style="background: #ebebeb none repeat scroll 0 0; color: #333;
                            display: inline-block; font-size: 12px; line-height: 20px; margin:
                            5px 5px 0 0; padding: 5px 15px; text-transform: capitalize;">
                                <a href="<?php echo e(route('shop.tag', $tag->slug)); ?>">
                                    <?php echo e($tag->name); ?>

                                    (<?php echo e($tag->products_count); ?>)
                                </a>
                            </span>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <div class="sidebar-widget mb-40">
        <h3 class="sidebar-title">RECENT REVIEWS</h3>
        <hr style="margin-top: 0; margin-bottom: 10px; border: solid 1px;">
        <ul>
            <?php $__currentLoopData = $recent_reviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $recent_review): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li>
                    <div class="post-wrapper d-flex">
                        <div class="mb-2">
                            <img src="<?php echo e(get_gravatar($recent_review->email, 50)); ?>" alt="<?php echo e($recent_review->name); ?>">
                        </div>
                        <div class="ml-3 p-0">
                            <?php if(isset($recent_review->product->slug)): ?>
                                <p>
                                    <span class=""><?php echo e($recent_review->user->full_name); ?></span>
                                    <small> review on :
                                        <?php echo e($recent_review->product->name); ?>

                                    </small>
                                </p>
                                <p><?php echo \Illuminate\Support\Str::limit($recent_review->review, 30, '...'); ?></p>
                            <?php else: ?>

                                <h6><span class="text-success"><?php echo e($recent_review->name); ?></span>
                                    <small> review : </small>
                                </h6>
                                <p><?php echo \Illuminate\Support\Str::limit($recent_review->review, 30, '...'); ?></p>

                            <?php endif; ?>
                        </div>
                    </div>
                </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
</div>
<?php /**PATH G:\xampp\htdocs\laravel-ecommerce-main\resources\views/partials/frontend/shop/sidebar.blade.php ENDPATH**/ ?>