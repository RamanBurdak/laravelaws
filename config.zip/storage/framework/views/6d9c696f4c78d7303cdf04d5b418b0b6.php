<div>
    <a class="nav-link dropdown-toggle" href="#" id="alertsDropdown" role="button"
       data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
        <i class="fas fa-bell fa-fw"></i>
        <!-- Counter - Alerts -->
        <span class="badge badge-danger badge-counter"><?php echo e($unReadNotificationsCount); ?></span>
    </a>
    <!-- Dropdown - Alerts -->
    <div class="dropdown-list dropdown-menu dropdown-menu-right shadow animated--grow-in"
         aria-labelledby="alertsDropdown">
        <h6 class="dropdown-header">
            Alerts Center
        </h6>
        <?php $__empty_1 = true; $__currentLoopData = $unReadNotifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <a class="dropdown-item d-flex align-items-center" wire:click="markAsRead('<?php echo e($notification->id); ?>')">
            <div class="mr-3">
                <div class="icon-circle bg-primary">
                    <i class="fas fa-file-alt text-white"></i>
                </div>
            </div>
            <div>

                <div class="small text-gray-500"><?php echo e($notification->data['created_date']); ?></div>
                <?php if($notification->type == 'App\Notifications\Backend\User\ReturnRequestOrderNotification'): ?>
                    <span class="font-weight-bold">
                        A return request with amount (<?php echo e($notification->data['amount']); ?>) from <?php echo e($notification->data['user_name']); ?>

                    </span>
                <?php else: ?>
                    <span class="font-weight-bold">
                        A new order with amount (<?php echo e($notification->data['amount']); ?>) from <?php echo e($notification->data['user_name']); ?>

                    </span>
                <?php endif; ?>
            </div>
        </a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <div class="dropdown-item text-center">No notifications found!</div>
        <?php endif; ?>

    </div>
</div>
<?php /**PATH G:\xampp\htdocs\laravel-ecommerce-main\resources\views/livewire/backend/notification-component.blade.php ENDPATH**/ ?>