<?php

return [
    'accept' => env('TAP_ACCEPT', ''),
    'authorization' => env('TAP_AUTHORIZATION', ''),
    'base_uri' => env('TAP_BASE_URI', ''),
    'timeout' => env('TAP_TIMEOUT', ''),
];
