<ul>
    <li><a href="{{ route('wishlist.index') }}"><i class="ti-heart"></i>({{ $wishlistCount }}) Wishlist</a></li>
</ul>
