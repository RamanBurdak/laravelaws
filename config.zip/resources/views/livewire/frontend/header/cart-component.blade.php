<div class="header-cart-4 furits-cart">

    <a class="icon-cart" href="{{route('cart.index')}}">
        <i class="ti-shopping-cart"></i>
        <span>{{ $cartCount }}</span>
    </a>

{{--    <a class="icon-cart" href="{{route('cart.index')}}">--}}
{{--        <span class="shop-count-furniture green">--}}
{{--            {{ $cartCount }}--}}
{{--        </span>--}}
{{--        <i class="ti-shopping-cart"></i>--}}
{{--    </a>--}}

</div>
