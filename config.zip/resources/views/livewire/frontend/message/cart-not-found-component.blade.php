<tr x-data="{ cartNoFound: @entangle('cartNoFound') }">
    <td x-show="cartNoFound" class="pl-0 border-light" colspan="5">
        <p class="text-center">No items found.</p>
    </td>
</tr>
