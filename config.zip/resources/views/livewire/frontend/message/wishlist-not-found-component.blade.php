<tr x-data="{ wishlistNoFound: @entangle('wishlistNoFound') }">
    <td x-show="wishlistNoFound" class="pl-0 border-light" colspan="5">
        <p class="text-center">No items found.</p>
    </td>
</tr>
